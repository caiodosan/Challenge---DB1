//
//  Usuarios.swift
//  appSchool
//
//  Created by CaioCunha on 10/05/24.
//

import Foundation

struct Usuarios: Codable{
    var id: Int
    var email: String
    var senha: String
    
}
